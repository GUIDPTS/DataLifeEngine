$(document).ready(function() {
//API browse :)
	var windowWidth = $(document).width();

//Sub menu & profile header
	$('.navigation_header > li').hover(function() {
		$('.sub_nav_header').hide();
		$(this).children('.sub_nav_header').stop(false, true).slideDown(200);
	},function() {
		$('.sub_nav_header').slideUp(150);
	});

	$('.profile_header').hover(function() {
		$('.func_profile_header').hide();
		$(this).children('.func_profile_header').stop(false, true).slideDown(300);
	},function() {
		$('.func_profile_header').slideUp(150);
	});
	
//Slider main
	$('.back_slide_panel > img').attr('width', windowWidth);
	$('.block_slider').hide(); $('.block_slider:first').show();
	var countSlider = $('.block_slider').length;
	var clickSlider = 0;
	var backSlider = 0;
	var heightSlider = $('.block_slider').height();
	var speedSlider = 400;
	var speedAutoSlider = 8000;

	$('.right_slider_panel').click(function() {
		clickSlider++;
		backSlider = clickSlider - 1;
		clearInterval(autoSliders);
		$('.block_slider').hide();
		$('.block_slider').children('.front_slide_panel').stop(false, true);
		$('.block_slider').children('.back_slide_panel').stop(false, true);
		$('.block_slider').children('.front_slide_panel').removeClass('slide_front_active');
		$('.block_slider').children('.back_slide_panel').removeClass('slide_back_active');
		$('.block_slider').children('.front_slide_panel').removeAttr('style');
		$('.block_slider').children('.back_slide_panel').removeAttr('style');
		if(clickSlider < countSlider) {
			$('.block_slider').eq(backSlider).show()
			$('.block_slider').eq(clickSlider).show();

			$('.block_slider').eq(backSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(backSlider).children('.back_slide_panel').addClass('slide_back_active');
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').addClass('slide_back_active');

			$('.block_slider').eq(clickSlider).children('.front_slide_panel').css("top", "-" + heightSlider + "px");
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').animate({"top": "0px"}, speedSlider);
			$('.block_slider').eq(backSlider).children('.front_slide_panel').animate({"top": heightSlider + "px"}, speedSlider);

			$('.block_slider').eq(clickSlider).children('.back_slide_panel').css("opacity", "0");
			$('.block_slider').eq(backSlider).children('.back_slide_panel').animate({"opacity": "0"}, speedSlider);
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').animate({"opacity": "1"}, speedSlider);
		}else{
			clickSlider = 0
			$('.block_slider:last').show();
			$('.block_slider:first').show();

			$('.block_slider:last').children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider:first').children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider:last').children('.back_slide_panel').addClass('slide_back_active');
			$('.block_slider:first').children('.back_slide_panel').addClass('slide_back_active');

			$('.block_slider:first').children('.front_slide_panel').css("top", "-" + heightSlider + "px");
			$('.block_slider:first').children('.front_slide_panel').animate({"top": "0px"}, speedSlider);
			$('.block_slider:last').children('.front_slide_panel').animate({"top": heightSlider + "px"}, speedSlider);

			$('.block_slider:first').children('.back_slide_panel').css("opacity", "0");
			$('.block_slider:last').children('.back_slide_panel').animate({"opacity": "0"}, speedSlider);
			$('.block_slider:first').children('.back_slide_panel').animate({"opacity": "1"}, speedSlider);
		};
		autoSliders=setInterval(autoClickSlider, speedAutoSlider);
	});
	
	$('.left_slider_panel').click(function() {
		clickSlider--
		backSlider = clickSlider + 1;
		clearInterval(autoSliders);
		$('.block_slider').hide();
		$('.block_slider').children('.front_slide_panel').stop(false, true);
		$('.block_slider').children('.back_slide_panel').stop(false, true);
		$('.block_slider').children('.front_slide_panel').removeClass('slide_front_active');
		$('.block_slider').children('.back_slide_panel').removeClass('slide_back_active');
		$('.block_slider').children('.front_slide_panel').removeAttr('style');
		$('.block_slider').children('.back_slide_panel').removeAttr('style');
		if(clickSlider > (-countSlider)) {
			$('.block_slider').eq(clickSlider).show()
			$('.block_slider').eq(backSlider).show();

			$('.block_slider').eq(backSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(backSlider).children('.back_slide_panel').addClass('slide_back_active');
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').addClass('slide_back_active');

			$('.block_slider').eq(clickSlider).children('.front_slide_panel').css("top", heightSlider + "px");
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').animate({"top": "0px"}, speedSlider);
			$('.block_slider').eq(backSlider).children('.front_slide_panel').animate({"top": "-" + heightSlider + "px"}, speedSlider);

			$('.block_slider').eq(clickSlider).children('.back_slide_panel').css("opacity", "0");
			$('.block_slider').eq(backSlider).children('.back_slide_panel').animate({"opacity": "0"}, speedSlider);
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').animate({"opacity": "1"}, speedSlider);
		}else{
			clickSlider = 0
			$('.block_slider').eq(backSlider).show();
			$('.block_slider:first').show();

			$('.block_slider').eq(backSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(backSlider).children('.back_slide_panel').addClass('slide_back_active');
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').addClass('slide_back_active');

			$('.block_slider').eq(clickSlider).children('.front_slide_panel').css("top", heightSlider + "px");
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').animate({"top": "0px"}, speedSlider);
			$('.block_slider').eq(backSlider).children('.front_slide_panel').animate({"top": "-" + heightSlider + "px"}, speedSlider);

			$('.block_slider').eq(clickSlider).children('.back_slide_panel').css("opacity", "0");
			$('.block_slider').eq(backSlider).children('.back_slide_panel').animate({"opacity": "0"}, speedSlider);
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').animate({"opacity": "1"}, speedSlider);
		};
		autoSliders=setInterval(autoClickSlider, speedAutoSlider);
	});

	function autoClickSlider(){
		clickSlider++;
		backSlider = clickSlider - 1;
		$('.block_slider').hide();
		$('.block_slider').children('.front_slide_panel').stop(false, true);
		$('.block_slider').children('.back_slide_panel').stop(false, true);
		$('.block_slider').children('.front_slide_panel').removeClass('slide_front_active');
		$('.block_slider').children('.back_slide_panel').removeClass('slide_back_active');
		$('.block_slider').children('.front_slide_panel').removeAttr('style');
		$('.block_slider').children('.back_slide_panel').removeAttr('style');
		if(clickSlider < countSlider) {
			$('.block_slider').eq(backSlider).show()
			$('.block_slider').eq(clickSlider).show();

			$('.block_slider').eq(backSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider').eq(backSlider).children('.back_slide_panel').addClass('slide_back_active');
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').addClass('slide_back_active');

			$('.block_slider').eq(clickSlider).children('.front_slide_panel').css("top", "-" + heightSlider + "px");
			$('.block_slider').eq(clickSlider).children('.front_slide_panel').animate({"top": "0px"}, speedSlider);
			$('.block_slider').eq(backSlider).children('.front_slide_panel').animate({"top": heightSlider + "px"}, speedSlider);

			$('.block_slider').eq(clickSlider).children('.back_slide_panel').css("opacity", "0");
			$('.block_slider').eq(backSlider).children('.back_slide_panel').animate({"opacity": "0"}, speedSlider);
			$('.block_slider').eq(clickSlider).children('.back_slide_panel').animate({"opacity": "1"}, speedSlider);
		}else{
			clickSlider = 0
			$('.block_slider:last').show();
			$('.block_slider:first').show();

			$('.block_slider:last').children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider:first').children('.front_slide_panel').addClass('slide_front_active');
			$('.block_slider:last').children('.back_slide_panel').addClass('slide_back_active');
			$('.block_slider:first').children('.back_slide_panel').addClass('slide_back_active');

			$('.block_slider:first').children('.front_slide_panel').css("top", "-" + heightSlider + "px");
			$('.block_slider:first').children('.front_slide_panel').animate({"top": "0px"}, speedSlider);
			$('.block_slider:last').children('.front_slide_panel').animate({"top": heightSlider + "px"}, speedSlider);

			$('.block_slider:first').children('.back_slide_panel').css("opacity", "0");
			$('.block_slider:last').children('.back_slide_panel').animate({"opacity": "0"}, speedSlider);
			$('.block_slider:first').children('.back_slide_panel').animate({"opacity": "1"}, speedSlider);
		};
	};

	autoSliders=setInterval(autoClickSlider, speedAutoSlider);

//Tab news category main
	$('.panel_tab_category').hide();
	$('.panel_tab_category:first').show();
	$('.tabs_category_main span:first').addClass('active');

	$('.tabs_category_main > span').click(function() {
		var indexTab = $(this).index();
		$('.panel_tab_category').hide();
		$('.tabs_category_main span').removeClass('active');
		$('.panel_tab_category').eq(indexTab).show();
		$(this).addClass('active');
	});

//Even user information
	$('.line_info_user_prof_grey:odd').removeClass('line_info_user_prof_grey').addClass('line_info_user_prof_width');

//Edit user
	$('#edit_user').click(function() {
		$('.edit_user_profile').slideToggle();
	});

//Tabs game full
	$('.panel_tabs_game > .tabs').hide();
	$('.panel_tabs_game > .tabs:first').show();
	$('.control_tabs_game > span:first').addClass('active');

	$('.control_tabs_game > span').click(function() {
		var IndexTab = $(this).index();
		$('.panel_tabs_game > .tabs').hide();
		$('.control_tabs_game > span').removeClass('active');
		$('.panel_tabs_game > .tabs').eq(IndexTab).show();
		$(this).addClass('active');
	});

//Auth
	$('.auth_function').click(function() {
		$('.window_auth').show();
		$('.block_auth').show();
		$('.block_auth').animate({top: "50%"}, 350);
	});

	$('.close_auth').click(function() {
		$('.window_auth').hide();
		$('.block_auth').removeAttr('style');
		$('.block_auth').hide();
		$('.block_auth').css("top", "-210px");
	});

//Placeholder text area
//message new
	$('.new_pm #comments').attr('placeholder','����� ���������:');

//Video full news
	$('.video_block_full_object > object').attr("width", "735");

//Main number game
	number_game = 0;
	for (var i = 0; 5 >= i; i++) {
		number_game++;
		$('#main_pop_pc > li > a > span.number_pop_game').eq(i).html('#' + number_game);
		$('#main_pop_xbox > li > a > span.number_pop_game').eq(i).html('#' + number_game);
		$('#main_pop_ps > li > a > span.number_pop_game').eq(i).html('#' + number_game);
	};
});
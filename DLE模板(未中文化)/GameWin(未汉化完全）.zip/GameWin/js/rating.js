$(document).ready(function() {
	// Rating game
	function RatingGame(){
		var countRating = $('.current-rating').attr('style');
		switch(countRating){
		case "width:0%;":
			$('#count_rating_game').html("0.0");
			break;
		case "width:10%;":
			$('#count_rating_game').html("1.0");
			break;
		case "width:20%;":
			$('#count_rating_game').html("2.0");
			break;
		case "width:30%;":
			$('#count_rating_game').html("3.0");
			break;
		case "width:40%;":
			$('#count_rating_game').html("4.0");
			break;
		case "width:50%;":
			$('#count_rating_game').html("5.0");
			break;
		case "width:60%;":
			$('#count_rating_game').html("6.0");
			break;
		case "width:70%;":
			$('#count_rating_game').html("7.0");
			break;
		case "width:80%;":
			$('#count_rating_game').html("8.0");
			break;
		case "width:90%;":
			$('#count_rating_game').html("9.0");
			break;
		case "width:100%;":
			$('#count_rating_game').html("10");
			break;
		default:
			$('#count_rating_game').html("0.0");
			break;
	};
	setTimeout(RatingGame, 1);
	};
	RatingGame()

});